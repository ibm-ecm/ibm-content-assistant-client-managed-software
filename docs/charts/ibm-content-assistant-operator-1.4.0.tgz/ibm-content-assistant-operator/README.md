# IBM Content Assistant Helm Chart

[![License](https://img.shields.io/badge/License-Apache%202.0-blue.svg)](https://opensource.org/licenses/Apache-2.0)

## Overview

This Helm chart deploys the **IBM Content Assistant (CAS) Operator** into a Kubernetes or OpenShift cluster. The operator manages the lifecycle of IBM Content Assistant deployments, which provide AI-powered GenAI connectors and vector database integration built on top of IBM FileNet Content Manager.

Once the operator is running, you deploy an IBM Content Assistant instance by creating a `CASCluster` Custom Resource.

---

## Prerequisites

| Requirement | Version |
|---|---|
| Kubernetes | >= 1.24 |
| OpenShift Container Platform | >= 4.10 |
| Helm | >= 3.10 |
| IBM Entitlement Key | Valid key with access to `icr.io` |

Before installing, create the IBM entitlement key pull secret in your target namespace:

```bash
kubectl create secret docker-registry ibm-entitlement-key \
  --docker-server=icr.io \
  --docker-username=cp \
  --docker-password=<YOUR_ENTITLEMENT_KEY> \
  -n <NAMESPACE>
```

---

## Installing the Chart

Add the IBM Content Assistant chart repository and install:

```bash
# Install with default values
helm install ibm-cas ./ibm-content-assistant -n <NAMESPACE>

# Install with custom values
helm install ibm-cas ./ibm-content-assistant -n <NAMESPACE> -f my-values.yaml

# Skip CRD installation (if CRDs are already installed)
helm install ibm-cas ./ibm-content-assistant -n <NAMESPACE> --skip-crds
```

---

## Upgrading the Chart

```bash
helm upgrade ibm-cas ./ibm-content-assistant -n <NAMESPACE>
```

---

## Uninstalling the Chart

```bash
helm uninstall ibm-cas -n <NAMESPACE>
```

> **Note:** CRDs are **not** deleted on `helm uninstall` to prevent accidental data loss. To manually remove the CRD:
>
> ```bash
> kubectl delete crd casclusters.cas.ibm.com
> ```

---

## Deploying IBM Content Assistant

After the operator is running, create a `CASCluster` Custom Resource to deploy the IBM Content Assistant application. Refer to the sample CR files:

- `descriptors/ibm_content_assistant_cr.yaml` — minimal required configuration
- `descriptors/ibm_content_assistant_full_cr.yaml` — full configuration with all options

### Minimal example

```yaml
apiVersion: cas.ibm.com/v1
kind: CASCluster
metadata:
  name: casdeploy
spec:
  appVersion: 1.0.0
  license:
    accept: true
  shared_configuration:
    sc_cas_license_type: "fncm"
    image_pull_secrets:
      - ibm-entitlement-key
    sc_image_repository: cp.icr.io
    root_ca_secret: cas-root-ca
    sc_deployment_platform: OCP
    storage_configuration:
      sc_slow_file_storage_classname: "ocs-storagecluster-cephfs"
  vector_database:
    vector_database_type: "opensearch"
    vector_database_url: "https://<opensearch-host>:9200"
    vector_database_secret_name: vector-database-secret
    vector_database_ssl_enabled: true
    vector_database_certificate: vector-database-certificate-secret
    vector_database_auth_type: BASICAUTH
```

Apply the CR:

```bash
kubectl apply -f <your-cas-cr.yaml> -n <NAMESPACE>
```

---

## Configuration

The following table lists the configurable parameters and their defaults.

### Operator Image

| Parameter | Description | Default |
|---|---|---|
| `image.repository` | Operator image repository | `icr.io/cpopen/ibm-content-assistant-operator` |
| `image.digest` | Image digest (used when `image.tag` is empty) | *(see values.yaml)* |
| `image.tag` | Image tag override (overrides digest) | `""` |
| `image.pullPolicy` | Image pull policy | `IfNotPresent` |

### Image Pull Secrets

| Parameter | Description | Default |
|---|---|---|
| `imagePullSecrets` | List of pull secret names | `[{name: ibm-entitlement-key}]` |

### Operator Deployment

| Parameter | Description | Default |
|---|---|---|
| `replicaCount` | Number of operator replicas | `1` |
| `operator.name` | Name of the operator deployment | `ibm-content-assistant-operator` |
| `operator.resources.limits.cpu` | CPU limit | `500m` |
| `operator.resources.limits.memory` | Memory limit | `128Mi` |
| `operator.resources.requests.cpu` | CPU request | `10m` |
| `operator.resources.requests.memory` | Memory request | `64Mi` |
| `operator.args` | Command arguments for the manager binary | `[--leader-elect, --health-probe-bind-address=:8081]` |

### Security Context

| Parameter | Description | Default |
|---|---|---|
| `operator.securityContext.runAsNonRoot` | Run container as non-root | `true` |
| `operator.containerSecurityContext.allowPrivilegeEscalation` | Allow privilege escalation | `false` |
| `operator.containerSecurityContext.readOnlyRootFilesystem` | Read-only root filesystem | `true` |

### Service Account & RBAC

| Parameter | Description | Default |
|---|---|---|
| `serviceAccount.create` | Create service account | `true` |
| `serviceAccount.name` | Service account name | `ibm-content-assistant-operator-sa` |
| `rbac.create` | Create RBAC resources (Role + RoleBinding) | `true` |

### Probes

| Parameter | Description | Default |
|---|---|---|
| `livenessProbe.initialDelaySeconds` | Liveness probe initial delay | `15` |
| `livenessProbe.periodSeconds` | Liveness probe period | `20` |
| `readinessProbe.initialDelaySeconds` | Readiness probe initial delay | `5` |
| `readinessProbe.periodSeconds` | Readiness probe period | `10` |

### Scheduling

| Parameter | Description | Default |
|---|---|---|
| `affinity` | Node affinity rules | amd64 required |
| `nodeSelector` | Node selector labels | `{}` |
| `tolerations` | Pod tolerations | `[]` |

### Labels and Annotations

| Parameter | Description | Default |
|---|---|---|
| `labels` | Common labels applied to all resources | `{release: "1.0.3"}` |
| `podAnnotations` | Annotations applied to the operator pod | IBM product annotations |
| `networkPolicyLabels` | Network policy labels for the operator pod | CAS egress labels |

---

## CRD Management

The `CASCluster` CRD is defined in `crds/casclusters.cas.ibm.com.yaml` and is automatically installed and upgraded by Helm. It is **not** removed on `helm uninstall` to prevent data loss.

```bash
# View installed CRD
kubectl get crd casclusters.cas.ibm.com

# Describe the CRD
kubectl describe crd casclusters.cas.ibm.com
```

---

## Testing

Run the bundled chart tests after installation:

```bash
helm test ibm-cas -n <NAMESPACE>
```

The test pod validates:
1. Operator deployment exists and is ready
2. Operator pods are in `Running` state
3. `casclusters.cas.ibm.com` CRD is installed
4. ServiceAccount exists
5. Role and RoleBinding exist
6. No critical errors in operator logs

---

## Troubleshooting

**Operator pod not starting:**
```bash
kubectl describe pod -n <NAMESPACE> -l control-plane=ibm-content-assistant-operator
kubectl logs -n <NAMESPACE> -l control-plane=ibm-content-assistant-operator --previous
```

**CASCluster CR not reconciling:**
```bash
kubectl describe casclusters -n <NAMESPACE>
kubectl logs -n <NAMESPACE> -l control-plane=ibm-content-assistant-operator -f
```

**View all resources:**
```bash
kubectl get all -n <NAMESPACE>
kubectl get events -n <NAMESPACE> --sort-by='.lastTimestamp'
```

---

## Support

- **Documentation:** https://www.ibm.com/docs/en/cacms/1.0.x
- **GitHub:** https://github.com/ibm-ecm/ibm-content-assistant-client-managed-software
- **Support:** ecm-container-service@ibm.com

---

## License

Licensed Materials - Property of IBM. (C) Copyright IBM Corp. 2026. All Rights Reserved.
